/**
 * 
 */

package edu.javarepublic.jpamapping.persistence;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringBootConfiguration;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import edu.javarepublic.jpamapping.JpamappingApplication;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * @author rmathew
 *
 */
@RunWith(SpringRunner.class)
@DataJpaTest
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
@SpringBootTest(classes = JpamappingApplication.class)
public class CustomerRepositoryTest
{

    /**
     * Private field that ___
     */
    @Autowired
    CustomerRepository customerRepository;

    @Test
    public void test()
    {
        assertThat(customerRepository.findOne(3443568L)).isNotNull();
    }

}
