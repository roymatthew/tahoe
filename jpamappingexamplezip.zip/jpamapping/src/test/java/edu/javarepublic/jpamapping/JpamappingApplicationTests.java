
package edu.javarepublic.jpamapping;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

/**
 * TODO This class ___
 *
 * @author rmathew
 */
@RunWith(SpringRunner.class)
@SpringBootTest
public class JpamappingApplicationTests
{

    /**
     * This method ___
     */
    @Test
    public void contextLoads()
    {
    }

}
