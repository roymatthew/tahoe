/**
 * 
 */
package edu.javarepublic.jpamapping;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.context.annotation.Profile;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;

import oracle.jdbc.pool.OracleDataSource;

import javax.sql.DataSource;
import javax.validation.constraints.NotNull;

import java.sql.SQLException;

/**
 * @author rmathew
 *
 */
@Configuration
@ConfigurationProperties("oracle")
public class OracleConfiguration 
{
	@NotNull
	private String username;
	@NotNull	
	private String password;
	@NotNull	
	private String url;
	/**
	 * @return the username
	 */
	public String getUsername() {
		return username;
	}
	/**
	 * @param username the username to set
	 */
	public void setUsername(final String username) {
		this.username = username;
	}
	/**
	 * @return the password
	 */
	public String getPassword() {
		return password;
	}
	/**
	 * @param password the password to set
	 */
	public void setPassword(final String password) {
		this.password = password;
	}
	/**
	 * @return the url
	 */
	public String getUrl() {
		return url;
	}
	/**
	 * @param url the url to set
	 */
	public void setUrl(final String url) {
		this.url = url;
	}
	
    /**
     * Entity manager factory.
     *
     * @return the local container entity manager factory bean
     */
    @Bean
    @Primary
    public LocalContainerEntityManagerFactoryBean entityManagerFactory() throws SQLException
    {
        final LocalContainerEntityManagerFactoryBean em = new LocalContainerEntityManagerFactoryBean();
        em.setDataSource(datasource());
        em.setPackagesToScan(new String[] { "edu.javarepublic.jpamapping.persistence" });
        em.setJpaVendorAdapter(new HibernateJpaVendorAdapter());
        em.setPersistenceUnitName("CustomerPersistence");
        
        return em;
    }	
	
	@Bean
	public DataSource datasource() throws SQLException
	{
		OracleDataSource datasource = new OracleDataSource();
		datasource.setURL(url);
		datasource.setUser(username);
		datasource.setPassword(password);
		return datasource;
		
	}

}
