/**
 * 
 */
package edu.javarepublic.jpamapping.persistence;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;



/**
 * @author rmathew
 *
 */
@Entity
@Table(schema = "BRAVURA", name = "BORROWER")
public class Customer implements Serializable
{
	/**
	 * Private field that ___
	 */
	@Id
    @GeneratedValue(strategy=GenerationType.AUTO)
    @Column(name="BORR_SK_SEQ")
	private Long customerKey;
	
    @Column(name="FIRST_NAME")
	private String firstName;
    @Column(name="LAST_NAME")
	private String lastName;
    /**
     * Getter for customerKey.
     *
     * @return the customerKey
     */
    public Long getCustomerKey()
    {
        return customerKey;
    }
    /**
     * Setter for customerKey.
     *
     * @param customerKey the customerKey to set
     */
    
    public void setCustomerKey(final Long customerKey)
    {
        this.customerKey = customerKey;
    }
    /**
     * Getter for firstName.
     *
     * @return the firstName
     */
    public String getFirstName()
    {
        return firstName;
    }
    /**
     * Setter for firstName.
     *
     * @param firstName the firstName to set
     */
    
    public void setFirstName(String firstName)
    {
        this.firstName = firstName;
    }
    /**
     * Getter for lastName.
     *
     * @return the lastName
     */
    public String getLastName()
    {
        return lastName;
    }
    /**
     * Setter for lastName.
     *
     * @param lastName the lastName to set
     */
    
    public void setLastName(String lastName)
    {
        this.lastName = lastName;
    }
	

}
