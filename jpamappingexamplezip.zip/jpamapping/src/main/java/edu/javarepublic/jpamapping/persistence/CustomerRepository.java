/**
 * 
 */
package edu.javarepublic.jpamapping.persistence;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

/**
 * @author rmathew
 *
 */
@Repository
public interface CustomerRepository extends JpaRepository<Customer, Long>
{

}
