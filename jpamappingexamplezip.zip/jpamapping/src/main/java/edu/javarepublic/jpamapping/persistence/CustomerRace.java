/**
 * 
 */
package edu.javarepublic.jpamapping.persistence;

/**
 * @author rmathew
 *
 */
public class CustomerRace {

}
