package edu.javarepublic.jpamapping;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JpamappingApplication {

	public static void main(String[] args) {
		SpringApplication.run(JpamappingApplication.class, args);
	}
}
