
grepm is a unix shell script tool to search for the given pattern in PROD mortracapp.log Depending on the user input at the command line, it would search all server instances or just one
and output the results if found in a text file in your home folder on wmonin.

Steps to install the tool
==========================

Put the script in your home directory on wmonin (/home/your username)

run the following to give permission to execute the script

> chmod 777 grepm

usage:
 > ./grepm <<all | serverinstance number>> <<pattern>>
 
 Eg:
 
 >./grepm all DAOException (looks for "DAOException" in mortracapp.log on all server instances)
 >./grepm 1 Could not execute jdbc batch (Looks for "Could not execute jdbc batch" in mortracapp.log on server1)
 
 
 >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
 
  tailm is a unix shell script tool to extract the last n lines from PROD mortracapp.log Depending on the user input at the command line, it would search all server instances or just one
  and output the results if found in a text file in your home folder on wmonin.
  
  Steps to install the tool
  ==========================
  
  Put the script in your home directory on wmonin (/home/your username)
  
  run the following to give permission to execute the script
  
  > chmod 777 tailm
  
  usage:
   > ./tailm <<linecount>> <<all | serverinstance number>>
   
   Eg:
   
   >./tailm 1000 all
 >./tailm 2000 1
 
 

 >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
 
 
 
 grepl is a unix shell script tool to search for the given pattern in PROD lending.log Depending on the user input at the command line, it would search all server instances or just one
 and output the results if found in a text file in your home folder on wmonin.
 
 Steps to install the tool
 ==========================
 
 Put the script in your home directory on wmonin (/home/your username)
 
 run the following to give permission to execute the script
 
 > chmod 777 grepl
 
 usage:
  > ./grepl <<all | serverinstance number>> <<pattern>>
  
  Eg:
  
  >./grepl all DAOException (looks for "DAOException" in Lending.log on all server instances)
 >./grepl 1 Could not execute jdbc batch (Looks for "Could not execute jdbc batch" in Lending.log on server1)
 
 
 >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
 
 
  taill is a unix shell script tool to extract the last n lines from PROD lending.log Depending on the user input at the command line, it would search all server instances or just one
  and output the results if found in a text file in your home folder on wmonin.
  
  Steps to install the tool
  ==========================
  
  Put the script in your home directory on wmonin (/home/your username)
  
  run the following to give permission to execute the script
  
  > chmod 777 taill
  
  usage:
   > ./taill <<linecount>> <<all | serverinstance number>>
   
   Eg:
   
   >./taill 1000 all
 >./taill 2000 1
 
 
 
 
 
