filepath=$1
starttime=$2
endtime=$3
datepattern=null
DFORMAT=temp
startline=0
endline=0
DFORMAT1=$(date +"%Y-%m-%d")
DFORMAT2=$(date +"%m-%d-%Y")
DFORMAT3=$(date +"%d %b %Y")
DFORMAT4=$(date +"%a %b %Y")
DATEFORMATCNT=4
DFFOUND=0
i=0
	while [ "$DATEFORMATCNT" -gt 0 ]
	do
   		i=`expr $i + 1`	
		if [ "$i" -eq 1 ]
		then
			DFORMAT=$DFORMAT1
		fi
		if [ "$i" -eq 2 ]
		then
			DFORMAT=$DFORMAT2
		fi
		if [ "$i" -eq 3 ]
		then
			DFORMAT=$DFORMAT3
		fi
		if [ "$i" -eq 4 ]
		then
			DFORMAT=$DFORMAT4
		fi
		DFFOUND=$(grep -n -i -r -o -m 1 "$DFORMAT" $filepath | wc -l)
		DATEFORMATCNT=`expr $DATEFORMATCNT - 1`
		if [ "$DFFOUND" -eq 1 ]
		then
			break
		fi   
	done	
	if [ "$DFFOUND" -eq 1 ]
	then
		datepattern=$DFORMAT\ $starttime
		startline=$(grep -n -i -r -m 1 "$datepattern" $filepath | cut -f1 -d':')
		datepattern=$DFORMAT\ $endtime		
		endline=$(grep -n -i -r -m 1 "$datepattern" $filepath | cut -f1 -d':')
		sed -n "$startline,${endline}p;${endline}q"
	fi
