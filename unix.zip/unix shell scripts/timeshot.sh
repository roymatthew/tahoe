#-------------------------------------------------------------------------------------------------------------------------------------------
#Script to extract lines from a file for the given time window.
#-------------------------------------------------------------------------------------------------------------------------------------------
if [ "$#" == 0 ]
then
	echo "usage: timeshot <<file path>> <<start time>> <<end time>>"
	exit
fi
echo Welcome to timeshot "The tool to extract entries for a given time window"!
#declare variables

starttime=$(date)
DFORMAT=temp
startline=0
endline=0
#LENDING_LOGS_ROOT=/export/reverse_mounts/whapp/logs
#LENDING_LOG=lendingjboss/Lending.log
#servername=whapp$1
#filename=grep_$servername_$(date)
#
#
if [ $1 == "help" ] 
then
	echo "usage: timeshot <<file path>> <<start time>> <<end time>>"
	exit
fi

#....................
#....................
#mmddyyyy
DFORMAT1=$(date +"%m-%d-%Y")
#yyyymmdd
DFORMAT2=$(date +"%Y-%m-%d")
#ddmmmyyyy
DFORMAT3=$(date +"%d %b %Y")
#daymmmdd
DFORMAT4=$(date +"%a %b %Y")
DATEFORMATCNT=4
DFFOUND=0
i=0

	#echo $DFORMAT1
	#echo $DATEFORMATCNT

	while [ "$DATEFORMATCNT" -gt 0 ]
	do

   		i=`expr $i + 1`	
   		#grep -iwn "$sstring" $LENDING_LOGS_ROOT/whapp$i/$LENDING_LOG >> $HOME/$filename
		if [ "$i" -eq 1 ]
		then
			DFORMAT=$DFORMAT1
		fi
		if [ "$i" -eq 2 ]
		then
			DFORMAT=$DFORMAT2
		fi
		if [ "$i" -eq 3 ]
		then
			DFORMAT=$DFORMAT3
		fi
		if [ "$i" -eq 4 ]
		then
			DFORMAT=$DFORMAT4
		fi
		echo "$i: Checking for date pattern $DATEFORMATCNT: $DFORMAT ************* "
		DFFOUND=$(grep -n -i -r -o -m 1 "$DFORMAT" $1 | wc -l)
   		#DATEFORMATCNT=$DATEFORMATCNT-1
		DATEFORMATCNT=`expr $DATEFORMATCNT - 1`
   		echo $DFFOUND occurence of $DFORMAT found.
		if [ "$DFFOUND" -eq 1 ]
		then
			#DFORMAT=$(DFORMAT$i)
			echo break from loop.
			break
		fi	
   
	done
	
	if [ "$DFFOUND" -eq 1 ]
	then
		echo starttime $2 endtime $3
		startline=$(grep -n -i -r -m 1 "$2" $1 | cut -f1 -d':')
		endline=$(grep -n -i -r -m 1 "$3" $1 | cut -f1 -d':')
		#startline='660985' 
		#endline='732593'
		echo "sed -n '$startline,${endline}p;${endline}q' $1 >> $HOME/timeshotres"
		sed -n "$startline,${endline}p;${endline}q" $1 >> $HOME/timeshotres
	fi	
	

#...................................
#...................................
#...................................



echo "Start: "$starttime
echo "End:   "$(date)
#echo "Output file name: "$filename
