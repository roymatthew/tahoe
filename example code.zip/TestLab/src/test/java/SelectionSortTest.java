/*
 *    Copyright &copy; Flagstar Bank 2018.
 *
 *    Copyright in the application source code, and in the information and
 *    material therein and in their arrangement, is owned by Flagstar Bank, FSB
 *    unless otherwise indicated.
 *
 *    You shall not remove or obscure any copyright, trademark or other notices.
 *    You may not copy, republish, redistribute, transmit, participate in the
 *    transmission of, create derivatives of, alter edit or exploit in any
 *    manner any material including by storage on retrieval systems, without the
 *    express written permission of Flagstar Bank.
 */
package test.java;

/**
 * SelectionSortTest.
 *
 * @author rmathew
 */
public class SelectionSortTest
{
    
    static final int[] arr = {4,5,6,2,1,7,10,3,8,9};
    
    public static void main(String args[])
    {   

        int temp = 0;
        for (int i = 0; i < arr.length; i++)
        {
            
            for (int j = (i + 1); j < arr.length; j++)
            {
                if (arr[j] < arr[i])
                {
                    temp = arr[j];
                    arr[j] = arr[i];
                    arr[i] = temp;
                    
                 }
            }
            
        }
        System.out.println("Sorted Result");
        for (int i = 0; i < arr.length; i ++)
        {
            System.out.println(arr[i]);
        }
    }

}

