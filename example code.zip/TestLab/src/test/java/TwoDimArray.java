
package test.java;

/**
 * TwoDimArray
 *
 * @author rmathew
 */
public class TwoDimArray
{
    private static int[][] intArray = new int[2][5];
    private static int[] bases = {2,3};

    public static void main(String args[])
    {
        for (int i = 0; i < 2; i++)
        {
            for (int j = 0; j < 5; j++)
            {
                intArray[i][j] = bases[i] * (j+1);
            }
        }
        
        for (int i = 0; i < 2; i++)
        {
            for (int j = 0; j < 5; j++)
            {
                System.out.print(intArray[i][j]);
                System.out.print(",");                
            }
            System.out.print("\n");             
        }
    }
}
