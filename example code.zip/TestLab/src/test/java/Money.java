package test.java;

public interface Money
{

    /**
     * This method ___
     * @return
     */
    
    CurrencyEnum getCurrency();
    
    public default Dollar dollar()
    {
        return new Dollar(CurrencyEnum.DOLLAR);
    }
}

