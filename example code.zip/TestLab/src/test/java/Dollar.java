
package test.java;

public class Dollar implements Money
{
    private CurrencyEnum currency;

    /**
     * Getter for currency.
     *
     * @return the currency
     */
    public CurrencyEnum getCurrency()
    {
        return currency;
    }

    /**
     * Constructs a ___
     * @param currency
     */
    public Dollar(CurrencyEnum currency)
    {
        super();
        this.currency = currency;
    }

    /**
     * Setter for currency.
     *
     * @param currency the currency to set
     */
    
    public void setCurrency(CurrencyEnum currency)
    {
        this.currency = currency;
    }
}
