
package test.java;

public enum CurrencyEnum
{
    DOLLAR("$", 1), RUPEE("\\u20B9", 70);

    private String symbol;
    private int exchangeRate;

    /**
     * Constructs a ___
     * 
     * @param symbol
     * @param exchangeRate
     */
    private CurrencyEnum(String symbol, int exchangeRate)
    {
        this.symbol = symbol;
        this.exchangeRate = exchangeRate;
    }

    /**
     * Getter for symbol.
     *
     * @return the symbol
     */
    public String getSymbol()
    {
        return symbol;
    }

    /**
     * Setter for symbol.
     *
     * @param symbol the symbol to set
     */
    
    public void setSymbol(String symbol)
    {
        this.symbol = symbol;
    }

    /**
     * Getter for exchangeRate.
     *
     * @return the exchangeRate
     */
    public int getExchangeRate()
    {
        return exchangeRate;
    }

    /**
     * Setter for exchangeRate.
     *
     * @param exchangeRate the exchangeRate to set
     */
    
    public void setExchangeRate(int exchangeRate)
    {
        this.exchangeRate = exchangeRate;
    }



}
