package test.java;

import java.util.Arrays;

public class ArrayWrapper
{
    
    private String[] localArray;

    /**
     * Constructor with String array argument.
     * @param colors
     */
    public ArrayWrapper(final String[] anArray)
    {        
        this.localArray = new String[anArray.length];
        this.localArray = Arrays.copyOf(anArray, anArray.length);
    }

    /**
     * This method ___
     * @return
     */
    
    public String[] getSortedArray()
    {
        // TODO Auto-generated method stub
        Arrays.sort(this.localArray);
        return this.localArray;
        
    }

}

