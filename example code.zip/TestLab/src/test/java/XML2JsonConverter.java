package test.java;

import org.json.JSONObject;
import org.json.XML;

public class XML2JsonConverter
{
    
    private static final String xmlString = "<myaddress type = \"Home\">Hello<street>5151 corporate dr</street>"
        + "<zipcode>48307</zipcode>"
        + "<state>MI</state>"
        + "<city>Troy</city>"
        + "</myaddress>";
    
    public static void main(String args[])
    {
        JSONObject jsonObject = XML.toJSONObject(xmlString);
        System.out.println(jsonObject.toString());
    }

}

