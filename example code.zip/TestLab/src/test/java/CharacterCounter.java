/*
 *    Copyright &copy; Flagstar Bank 2018.
 *
 *    Copyright in the application source code, and in the information and
 *    material therein and in their arrangement, is owned by Flagstar Bank, FSB
 *    unless otherwise indicated.
 *
 *    You shall not remove or obscure any copyright, trademark or other notices.
 *    You may not copy, republish, redistribute, transmit, participate in the
 *    transmission of, create derivatives of, alter edit or exploit in any
 *    manner any material including by storage on retrieval systems, without the
 *    express written permission of Flagstar Bank.
 */
package test.java;

/**
 * CharacterCounter.
 *
 * @author rmathew
 */
public class CharacterCounter
{

    /**
     * This method ___
     * @param args
     */
    public static void main(final String[] args)
    {
        //final String input = "rrraaaajjk";
        final String input = "raaaajjjkk";        
        final String output = compressString(input);
        System.out.println("Compressed String: " + output);

    }

    /**
     * This method ___
     * @param input
     * @return
     */
    
    private static String compressString(final String input)
    {
        char[] cA = input.toCharArray();
        int len = cA.length;
        char repeatChar = ' ';
        int repeatCount = 0;
        String output = "";
        for (int i=0; i < len; i++)
        {
            repeatChar = cA[i];
            repeatCount++;

            if (i+1 == len)
            {
              
                output = output.concat(String.valueOf(repeatChar) + repeatCount);
            }          
            else if ((i+1) < len && cA[i] != cA[i+1])
            {
                output = output.concat(String.valueOf(repeatChar) + repeatCount);
                repeatCount = 0;                
            }
            else
            {               
                continue;
            }
        }
        return output;
        
    }

}

