import org.junit.Assert;
import org.junit.jupiter.api.Test;

import test.java.ArrayWrapper;

/**
 * ArrayWrapperTest
 *
 * @author rmathew
 */
class ArrayWrapperTest
{
    
    private final String[] colors = {"red","blue","green","yellow","magenta","black"};

    @Test
    void test()
    {

        final ArrayWrapper arrayWrapper = new ArrayWrapper(colors);
        Assert.assertNotNull(arrayWrapper);
    }
    
    @Test
    void testSortedArray()
    {
        final ArrayWrapper arrayWrapper = new ArrayWrapper(colors);
        final String[] sortedArray = arrayWrapper.getSortedArray();
        Assert.assertNotNull(sortedArray);
        Assert.assertEquals("black", sortedArray[0]);
        Assert.assertEquals("blue", sortedArray[1]);
        Assert.assertEquals("yellow", sortedArray[5]);        
    }    

}

