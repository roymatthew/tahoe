var express = require('express');
var router = express.Router();
var User = require('../app/models/user'); // get our mongoose user model
var Client = require('../app/models/client'); // get our mongoose client model
var base64 = require('base-64');
var utf8 = require('utf8');

/* GET users listing. */
router.get('/', function (req, res, next) {
  //res.send('respond with a resource');
  console.log('Enter user listing');
  User.find({}, function (err, users) {
    res.json(users);
  });
});

/*router.get('/setup', function (req, res) {

  console.log('Enter user setup');
  // create a sample user
  var nick = new User({
    name: 'Nick Cerminara',
    password: 'password',
    admin: true
  });
  console.log('mongo User object created');
  // save the sample user
  nick.save(function (err) {
    if (err) throw err;

    console.log('User saved successfully');
    res.json({ success: true });
  });
});*/

router.post('/setup', function (req, res) {

  console.log('Enter user setup');
  const jsonText = JSON.stringify(req.body);
  const requestUser = JSON.parse(jsonText);
  console.log('requestUser' + requestUser.loginname);
  // create a sample user
  var aUser = new User({
    loginname: requestUser.loginname,
    password: requestUser.password,
    application: requestUser.application,
    admin: requestUser.admin
  });
  console.log('mongo User object created');
  // save the sample user
  aUser.save(function (err) {
    if (err) throw err;
    console.log('User saved successfully');
    res.json({ success: true });
  });
});

router.post('/client/setup', function (req, res) {

  console.log('Enter client setup');
  const jsonText = JSON.stringify(req.body);
  const requestClient = JSON.parse(jsonText);
  let secretbytes = utf8.encode(requestClient.secret);
  let encodedSecret = base64.encode(secretbytes);
  // create a sample user
  var aClient = new Client({
    clientid: requestClient.clientid,
    secret: encodedSecret,
    application: requestClient.application
  });
  console.log('mongo Client object created');
  // save the sample user
  aClient.save(function (err) {
    if (err) throw err;
    console.log('Client saved successfully');
    res.json({ success: true });
  });
});

module.exports = router;
