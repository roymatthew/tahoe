var express = require('express');
var router = express.Router();
var config = require('../config');
var User = require('../app/models/user'); // get our mongoose model
var Client = require('../app/models/client');
var base64 = require('base-64');
var utf8 = require('utf8');
var jwt = require('jsonwebtoken');
const moment = require('moment');
var jwtDecode = require('jwt-decode');




/*router.all('/*', function(req, res, next) {
  res.header("Access-Control-Allow-Origin", "*");
  //res.header("Access-Control-Allow-Origin", "http://localhost:3000");
  res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
  next();
});*/

router.get('/', function (req, res, next) {
    //res.send('respond with a resource');
    try {
        let bytes = base64.decode('2d4f882726acf77de281458672708859:lv=1463750901347:ss=1463750901347');
        let decodedToken = utf8.decode(bytes);
        console.log('decodedToken' + decodedToken);
    } catch (Error) {
        console.log('Error when doing decoding encoded string: ' + Error.message);
    }

    res.json({ message: 'Welcome to the coolest API on earth!' });
});


router.post('/authenticate', function (req, res) {


    console.log('Enter /auth/authenticate');
    const jsonText = JSON.stringify(req.body);
    const requestUser = JSON.parse(jsonText);
    console.log('requestUser' + requestUser.loginname);

    // find the user
    User.findOne({
        loginname: requestUser.loginname
    }, function (err, user) {

        if (err) throw err;

        if (!user) {
            res.json({ success: false, message: 'Authentication failed. User not found.' });
        } else if (user) {

            // check if password matches
            if (user.password != requestUser.password) {
                res.json({ success: false, message: 'Authentication failed. Wrong password.' });
            } else {

                res.json({ success: true, message: 'Authentication success!.' });
            }

        }

    });
});

router.post('/accesstoken', function (req, res) {


    console.log('Enter /auth/accesstoken');
    const jsonText = JSON.stringify(req.body);
    const requestUser = JSON.parse(jsonText);
    console.log('requestUser: ' + requestUser.loginname);

    // find the user
    User.findOne({
        loginname: requestUser.loginname
    }, function (err, user) {

        if (err) throw err;

        if (!user) {
            res.json({ success: false, message: 'Authentication failed. User not found.' });
        } else if (user) {

            //let bytes = base64.decode(requestUser.password);
            //let decodedPassword = utf8.decode(bytes);

            // check if password matches
            //if (user.password != decodedPassword) {
            //    res.json({ success: false, message: 'Authentication failed. Wrong password.' });
            //} else {

            let clientSecret = '';

            Client.findOne({
                application: user.application
            }, function (err, client) {
                if (!client) {
                    res.json({ success: false, message: 'Cannot create access token.Authentication failed.' });
                } else if (client) {

                    let bytes = base64.decode(client.secret);
                    let decodedSecret = utf8.decode(bytes);
                    console.log('secret:' + decodedSecret);
                    clientSecret = decodedSecret;
                }

            });

            const expires = moment().add(1800, 'seconds').valueOf();
            //create a wrapper object and add profile
            var userWrapper = {
                'user': user,
                'resources': [
                    "203K",
                    "ADMN",
                    "ADPL",
                    "AEML",
                    "AERP",
                    "APSP",
                    "ARCH",
                    "ARTW"]
            };
            var token = jwt.sign(userWrapper, 'loantracsecret', {
                expiresIn: expires // expires in 30m in
            });
            // just to see the contents of token
            var decoded = jwtDecode(token);
            console.log(decoded);

            res.json({
                success: true,
                message: 'Enjoy your token!',
                token: token
            });
            //}

        }

    });
});


// loan authorization
router.post('/authorizeLoan', function (req, res) {

    console.log('Enter /auth/authorizeLoan');
    const jsonText = JSON.stringify(req.body);
    const requestJSON = JSON.parse(jsonText);
    console.log('token:' + requestJSON.token);
    console.log('loanNumber:' + requestJSON.loanNumber);
	if (requestJSON.loanNumber === '543212345')
	{
		res.status(400).json({ userStatus : 'User is not authorized' });
	}
	else if (requestJSON.loanNumber === '123456789')
	{
		res.status(200).json({ userStatus : 'Authorized' });
	}

	//res.sendStatus(200);
});

// ---------------------------------------------------------
// route middleware to authenticate and check token
// ---------------------------------------------------------
router.use(function (req, res, next) {

    console.log('Enter router.use');

    // check header or url parameters or post parameters for token
    var token = req.body.token || req.param('token') || req.headers['x-access-token'];

    // decode token
    if (token) {

        // verifies secret and checks exp
        jwt.verify(token, config.secret, function (err, decoded) {
            if (err) {
                return res.json({ success: false, message: 'Failed to authenticate token.' });
            } else {
                // if everything is good, save to request for use in other routes
                req.decoded = decoded;
                next();
            }
        });

    } else {

        // if there is no token
        // return an error
        return res.status(403).send({
            success: false,
            message: 'No token provided.'
        });

    }

});


module.exports = router;