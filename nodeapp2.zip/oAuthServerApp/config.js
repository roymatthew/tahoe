module.exports = {

    'secret': 'loantractospasecret',
    'database': 'mongodb://localhost:27017/test'

};