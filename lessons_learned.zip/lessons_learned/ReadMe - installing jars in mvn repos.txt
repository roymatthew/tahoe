mvn install:install-file -DgroupId=com.fsb -DartifactId=mortrac-client -Dversion=local-SNAPSHOT -Dpackaging=jar -Dfile=C:\workspace\contracts\Mortrac\ejb\mortrac-client-local.jar

mvn install:install-file -DgroupId=com.fsb -DartifactId=warehouseadvanceservice-client-contract -Dversion=local-SNAPSHOT -Dpackaging=jar -Dfile=C:\workspace\warehouseadvanceservice-client-contract-local.jar

mvn install:install-file -DgroupId=com.fsb -DartifactId=advancedataservice-client-contract -Dversion=local-SNAPSHOT -Dpackaging=jar -Dfile=C:\workspace\advancedataservice-client-contract-local.jar

mvn install:install-file -DgroupId=com.fsb -DartifactId=mortgagefraudservice-client-contract -Dversion=local-SNAPSHOT -Dpackaging=jar -Dfile=C:\workspace\mortgagefraudservice-client-contract-local.jar