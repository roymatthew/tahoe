var express = require('express');
var cookieParser = require('cookie-parser');
var router = express.Router();
var fs = require("fs");
var http = require('http');
var https = require('https');
var store = require('store');
var base64 = require('base-64');
var utf8 = require('utf8');
var jwtDecode = require('jwt-decode');

router.use(cookieParser());

//called from index.html, when login form is submitted
//renders the menu.html page
router.get('/decode', function (req, res, next) {

    const query = require('url').parse(req.url, true).query;
    console.log("inside token/decode");
    //console.log(query);
    console.log("token:" + query.token);
    let decoded = '';
    let bytes = '';
    if (query.token === '' && query.jwt != '')
    {
        decoded = jwtDecode(query.jwt);
    }
    else if (query.token != '' && query.jwt === '')
    {
        bytes = base64.decode(query.token);
        decoded = bytes;
    }
    else if (query.token != '' && query.jwt != '')
    {
        decoded = 'Bad Request!';
    }
    
	
    //let decoded = utf8.decode(bytes);
    console.log('decodedToken' + decoded);
	var jsonString = JSON.stringify(decoded);
    //console.log("Decoded token:" + jsonString);
    res.send(jsonString);
});

router.post('/exchangeshorttoken', function (req, res, next) {

    console.log('Enter exchangeshorttoken');
    const query = require('url').parse(req.url, true).query;
    //console.log('exchangeshorttoken()-->' + req.body);
    const body = 'username=rmathew&password=Jun20176*&authorized_user=rmathew_w';
    getAccessToken(body, function (statusCode, tokenObject) {

            res.send(tokenObject);

    });

    //console.log('Nothing to do..exiting...');

});

//talks to OAuth server either directly on thru API/Gateway to receive access token
function getAccessToken(inBody, onResult) {

    console.log("Enter getAccessToken");

    let outToken = {
        "access_token"
        : "dummyToken",
        "refresh_token"
        : "dummyToken"        
    };

    const urlPath = '/fsb-security/tokenservices/oauth/token?grant_type=password';
    const options = {
        hostname: 'www.dev.flagstar.com',
        path: urlPath,
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
            'Authorization': 'Basic ZmVlX3N1bW1hcnlfdGVtcDpmZWVmdW5zZWM='
        }
    };

    const req = https.request(options, (res) => {
        console.log(`STATUS: ${res.statusCode}`);
        console.log(`HEADERS: ${JSON.stringify(res.headers)}`);
        res.setEncoding('utf8');
        var text = '';
        //var jsonText = '';
        res.on('data', (chunk) => {
            //console.log(`BODY: ${chunk}`);
            text += chunk;

        });
        res.on('end', () => {
            console.log('No more data in response.');
            //jsonText = JSON.stringify(text);
            //console.log('text: ' + text);
            if (res.statusCode == 200) {
                outToken = JSON.parse(text);
                //console.log('getAccessToken() token received: ' + outToken);
            }
            onResult(res.statusCode, outToken);

        });
    });

    req.on('error', (e) => {
        console.error(`problem with request: ${e.message}`);
    });

    // write data to request body
    console.log('Write post data to request');
    req.write(inBody);
    console.log('End request');
    req.end();
}


module.exports = router;