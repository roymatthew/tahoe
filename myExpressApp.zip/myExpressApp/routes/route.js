var express = require('express');
var cookieParser = require('cookie-parser');
var router = express.Router();
var fs = require("fs");
var http = require('http');
var https = require('https');
var store = require('store');
var base64 = require('base-64');
var utf8 = require('utf8');

router.use(cookieParser());

/* GET fees listing. */
router.get('/', function (req, res, next) {
    fs.readFile("./public/data/" + "fees.json", 'utf8', function (err, data) {
        res.send(data);
    });
});

//called from index.html, when login form is submitted
//renders the menu.html page
router.get('/login', function (req, res, next) {

    const query = require('url').parse(req.url, true).query;
    console.log("inside fees/login");
    console.log('Cookies: ', req.cookies);
    console.log(query);
    console.log("loginname:" + query.loginname + " password: " + query.password);
    const passwordbytes = utf8.encode(query.password);
    //const thePassword = base64.encode(passwordbytes);
    const thePassword = query.password;
    store.set('user', { loginname: query.loginname, password: thePassword });
    //res.cookie('ssotoken', 'loantracssotoken', { maxAge: 1800 });
    //res.cookie(name , 'value', {expire : new Date() + 9999});
    //res.clearCookie(‘cookie_name’);
    //res.cookie('ssotoken', query.loginname + '.loantracclientid.loantracsecret');    
    res.render('menu', { title: 'Express' });
});
//called when release link is clicked from menu page
router.get('/releaseinfo', function (req, res, next) {
    var urlPath = 'http://wholesale.local.flagstar.com:3000';
    console.log(urlPath);
    //console.log('Cookies: ', req.cookies);
    console.log('Cookie: ', req.cookies.ssotoken_local);
    let user = store.get('user');
    console.log("user from store: " + user.loginname);
    console.log("password from store: " + user.password);
    //res.redirect(urlPath);
    getShortToken(user, function (statusCode, tokenObject) {
        //console.log("tokenObject.access_token: " + tokenObject.access_token);
        if (statusCode == 200 && tokenObject.access_token !== 'dummyToken') {
            console.log("onResult() Received access token at" + new Date());
            //store.set('id_token', tokenObject);
            //res.cookie('ssoAccess_local', tokenObject.access_token);
            //res.cookie('ssoAccess_local', tokenObject.access_token, { domain: 'localhost:3000', path: '/'});
            console.log("Now removing user from store..");
            store.remove('user');
            urlPath = urlPath + '?loanNumber=602814957&username='+ user.loginname +'&token=' + tokenObject.access_token;
            res.redirect(urlPath);
        }
        else {
            res.render('index', { title: 'Failed to obtain access token!' });
        }
    });


});

//talks to OAuth server either directly on thru API/Gateway to receive access token
function getShortToken(user, onResult) {

    //console.log("user from getAccessToken: " + user.loginname);
    //console.log("password from getAccessToken: " + user.password);

    let accessToken = {
        "access_token"
        : "dummyToken"
    };
    /*const postData = JSON.stringify({
        username: user.loginname,
        password: user.password
    });*/
    const postData = 'username=' + user.loginname + '&password=' + user.password;

    const options = {
        hostname: 'www.dev.flagstar.com',
        path: '/fsb-security/tokenservices/oauth/token?grant_type=client_credentials',
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
            'Authorization': 'Basic ZmVlX3N1bW1hcnlfc2hvcnQ6cmZzYWp3dHNob3J0',
            'Content-Length': Buffer.byteLength(postData)
        }
    };

    const req = https.request(options, (res) => {
        console.log(`STATUS: ${res.statusCode}`);
        console.log(`HEADERS: ${JSON.stringify(res.headers)}`);
        res.setEncoding('utf8');
        var text = '';
        //var jsonText = '';
        res.on('data', (chunk) => {
            //console.log(`BODY: ${chunk}`);
            text += chunk;

        });
        res.on('end', () => {
            console.log('No more data in response.');
            //jsonText = JSON.stringify(text);
            //console.log('text: ' + text);
            if (res.statusCode == 200) {
                accessToken = JSON.parse(text);
                console.log('getShortToken() token received: ' + accessToken);
                console.log('getShortToken() access_token: ' + accessToken.access_token);
            }
            onResult(res.statusCode, accessToken);

        });
    });

    req.on('error', (e) => {
        console.error(`problem with request: ${e.message}`);
    });

    // write data to request body
    console.log('Write post data to request');
    req.write(postData);
    console.log('End request');
    req.end();
}


module.exports = router;



