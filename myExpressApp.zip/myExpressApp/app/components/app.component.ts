import {Component} from "@angular/core";

@Component({
    selector: "app",
    template:`
    <h1>Welcome to angular</h1>
    `,
})
export class AppComponent{}