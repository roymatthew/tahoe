module.exports = {
    'jwtTokenSecret': 'loantractospasecret',
    'database': 'mongodb://localhost:27017/test'
};