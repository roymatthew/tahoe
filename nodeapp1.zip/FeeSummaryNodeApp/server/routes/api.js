const express = require('express');
var cookieParser = require('cookie-parser');
const http = require('http');
const router = express.Router();
//const jwt = require('jsonwebtoken');
const jwt = require('jwt-simple');
const moment = require('moment');
const config = require('../config');
var base64 = require('base-64');
var utf8 = require('utf8');
var Release = require('../models/release'); // get our mongoose model

router.use(cookieParser());

/* GET api listing. */
router.get('/', (req, res) => {
    res.send('api works');
});

/* GET api listing. */
router.get('/releaseinfo', (req, res) => {
    var theData = require('../data/release-info');
    res.send(theData);
});
router.get('/dashboard', (req, res) => {

    var theData = require('../data/release-info');
    res.send(theData);

});

router.get('/shorttoken', (req, res) => {

    var theData = require('../data/security-token');
    res.send(theData);

});

router.post('/shorttoken', (req, res) => {

    const jsonText = JSON.stringify(req.body);
    const credentials = JSON.parse(jsonText);
    let theData = require('../data/security-token');
    console.log("credentials.userid: " + credentials.userid);
    console.log("credentials.password: " + credentials.password);
    console.log('Cookies: ', req.cookies);
    //console.log("credentials.password decoded: " + atob(credentials.password));
    //let bytes = base64.decode(credentials.password);
    //let text = utf8.decode(bytes);
    //console.log("credentials.password decoded:" + text);
    if (credentials != 'undefined' && credentials.userid === 'rmathew') {

        console.log("userid validation pass..Create jwt token at: " + moment().format());
        const expires = moment().add(1800, 'seconds').valueOf();
        console.log("token expires at: " + moment(expires).format());
        const user = { userId: credentials.userid, password: '', authorities: ['APSP', 'ARCH', 'ASND', 'BETA', 'CBAV', 'CCRM', 'CLRO'] };
        const token = jwt.encode({
            iss: credentials.userid,
            exp: expires
        }, config.jwtTokenSecret);

        res.json({
            token: token,
            expires: expires,
            user: user
        });

    }
    else {
        theData = {
            "token": "invalid",
            "expires": 1
        }
        res.send(theData);
    };


});

router.post('/release/setup', function (req, res) {

    console.log('Enter release setup');
    const jsonText = JSON.stringify(req.body);
    const requestRelease = JSON.parse(jsonText);
    console.log('requestUser' + requestRelease.releaseid);
    // create a sample user
    var aRelease = new Release({
        releaseid: requestRelease.releaseid,
        jiraid: requestRelease.jiraid,
        releasedate: requestRelease.releasedate,
        description: requestRelease.description,
        comments: requestRelease.comments
    });
    console.log('mongo Release object created');
    // save the sample user
    aRelease.save(function (err) {
        if (err) throw err;
        console.log('Release saved successfully');
        res.json({ success: true });
    });
});

router.post('/releaseid/lookup', (req, res) => {

    const jsonText = JSON.stringify(req.body);
    console.log('api/releaseid/lookup - criteria: ' + jsonText);
    const criteria = JSON.parse(jsonText);

    var query = Release.find({});

    query.where('releaseid', criteria.releaseId);
    query.exec(function (err, docs) {
        res.json(docs);
    });


});

/*
    var query = Release.find({});

    query.where('releaseid', '156');
    //query.limit(5);
    //query.skip(100);

    query.exec(function (err, docs) {
        res.send(docs);
    });

    var query = Release.findOne({ 'releaseid': criteria.releaseId });

    query.exec(function (err, release) {
        if (err) return handleError(err);
        //console.log('%s %s is a %s.', person.name.first, person.name.last, person.occupation) // Space Ghost is a talk show host.
        res.json({ 'Release': release });
    })
*/

module.exports = router;