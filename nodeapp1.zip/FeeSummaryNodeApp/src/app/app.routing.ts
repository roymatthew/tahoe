import { ReleaseLookupComponent } from './release-info/components/release-lookup.component';
import { ReleaseInfoComponent } from './release-info/components/release-info.component';
import { FeeInfoComponent } from './fee/components/fee-info.component';
import { AppComponent } from './app.component';
import { Routes, RouterModule, CanActivate } from '@angular/router';
import { AuthGuard } from './auth-guard.service';
const appRoutes: Routes = [
    {
        path: '',
        redirectTo: '/dashboard',
        pathMatch: 'full'
    },
    {
        path: 'dashboard',
        component: ReleaseInfoComponent
    },
    {
        path: 'lookup',
        component: ReleaseLookupComponent,
        canActivate: [AuthGuard]
    },
    {
        path: 'feeinfo',
        component: FeeInfoComponent,
        canActivate: [AuthGuard]
    },];

export const routing = RouterModule.forRoot(appRoutes);
export const routedComponents = [ReleaseInfoComponent, ReleaseLookupComponent, FeeInfoComponent];
