import { Credentials } from './shared/models/Credentials';
import { Component } from '@angular/core';
import { Cookie } from 'ng2-cookies';
//import { GatewayService } from './shared/services/gateway.service';
import { AuthService } from './shared/services/auth.service';
import { SecurityToken } from './shared/models/SecurityToken';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { QueryParamHelper } from './shared/util/query-param-helper';
//import {DatepickerModule} from 'ng2-bootstrap';


@Component({
  selector: 'app-root',
  template: `
<nav>
  <a routerLink="dashboard" routerLinkActive="active">Dashboard</a>   
  <a routerLink="lookup" *ngIf="authService.loggedIn()" routerLinkActive="active">Lookup</a>
  <a routerLink="feeinfo" *ngIf="authService.loggedIn()" routerLinkActive="active">Get Fee Info</a>  
  <a (click)=authService.login() *ngIf="!authService.loggedIn()">Log In</a>
  <a (click)=authService.logout() *ngIf="authService.loggedIn()">Log Out</a>
  <a href="http://localhost:5000" routerLinkActive="active">Back to Parent</a>
</nav>
<router-outlet></router-outlet>
`,
  styleUrls: ['app.component.css']
})
export class AppComponent {
  title = 'Title from app component!';
  //private shortToken: SecurityToken;
  //private ssoTokenCookie: string;
  //cookies: Object;
  //keys: Array<string>;

  constructor(private authService: AuthService, private activatedRoute: ActivatedRoute) { }

  /*constructor(
    private gatewaySvc: GatewayService,
  ) { }
*/


  public ngOnInit() {

    const queryParamHelper = new QueryParamHelper();
    console.log('window.location.href' + window.location.href);
    const loanNumber = queryParamHelper.getParameterByName('loanNumber', window.location.href);
    const loggedInUser = queryParamHelper.getParameterByName('username', window.location.href);
    const shortToken = queryParamHelper.getParameterByName('token', window.location.href);
    console.log('Loan number from parent app' + loanNumber);
    console.log('User authenticated in parent app' + loggedInUser);
    // sessionStorage.setItem('loanNumber', loanNumber);
    // sessionStorage.setItem('loggedInUser', loggedInUser);
    sessionStorage.setItem('loanNumber', loanNumber);
    sessionStorage.setItem('loggedInUser', loggedInUser);
    sessionStorage.setItem('shortToken', shortToken);

    this.authService.login();

    // read the cookie value set from the calling app
    /*this.getSsoTokenCookie();
    const res = this.ssoTokenCookie.split('.');
    console.log('userid:' + res[0]);
    console.log('clientId:' + res[1]);
    console.log('secret:' + res[2]);
    // lets try to add a cookie
    // Cookie.set('acookie', 'testcookie');
    console.log('Calling Service with valid credentials');
    this.gatewaySvc.getAcessToken({
      loginname: res[0],
      password: btoa('rp4ang2'),
      clientId: res[1],
      secret: res[2],
    }).then((sToken: SecurityToken) => {
      this.shortToken = sToken;
      console.log('ShortToken received: ' + sToken.token);
    });
    this.clearSsoTokenCookie(); // once access token is obtained, clear the cookie??*/
  }

  /*getSsoTokenCookie() {
    this.cookies = Cookie.getAll();
    this.keys = Object.keys(this.cookies);
    console.log('Here are the cookies: ' + this.keys);
    if (Cookie.check('ssotoken')) {
      console.log('Here is ssotoken value: ' + Cookie.get('ssotoken'));
      this.ssoTokenCookie = Cookie.get('ssotoken');
    }
  }

  clearSsoTokenCookie() {
    if (Cookie.check('ssotoken')) {
      console.log('removing: ssotoken');
      Cookie.delete('ssotoken');
    }
  }*/
}
