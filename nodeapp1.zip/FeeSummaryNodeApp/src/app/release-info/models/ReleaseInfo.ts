
export interface ReleaseInfo {
    releaseid: string;
    jiraid: string;
    description: string;
    releasedate: any;
    docFolder: string;
}
