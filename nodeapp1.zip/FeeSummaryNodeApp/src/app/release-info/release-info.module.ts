import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReleaseInfoComponent } from './components/release-info.component';
import { ReleaseInfoService } from './services/release-info.service';
@NgModule({
    imports: [CommonModule],
    declarations: [ReleaseInfoComponent],
    exports: [ReleaseInfoComponent],
    providers: [ReleaseInfoService],
})
export class ReleaseInfoModule{}