import { Component } from '@angular/core';
import { ReleaseInfo } from '../models/ReleaseInfo';
import { ReleaseInfoService } from './../services/release-info.service';
import { AuthService } from '../../shared/services/auth.service';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { FormControl, FormGroup } from '@angular/forms';
import { Criteria } from './../../shared/models/criteria';


@Component({
    selector: 'release-lookup',
    template: `
    <h3>Release Lookup Component</h3>
    <form novalidate [formGroup]="releaseLookupForm">
    <div>
        <label for="release-number-input">Release#</label>
        <input type="text" id="release-number-input" formControlName="releaseNumberInput">
        <button type="button" (click)="doSearchByReleaseNumber()">Lookup</button>            
    </div>
    <!--<div>
    <dp-day-picker [(ngModel)]="selectedDate" [config]="datePickerConfig"></dp-day-picker>
    </div>-->
    <div>
        <li *ngFor="let releaseInfo of releaseInfoList">{{releaseInfo.releaseid}}</li>
    </div>
    </form>`,
})
export class ReleaseLookupComponent {

    public releaseLookupForm = new FormGroup({
        releaseNumberInput: new FormControl(''),
    });

    releaseInfoList: ReleaseInfo[];

    constructor(
        private releaseInfoSvc: ReleaseInfoService<ReleaseInfo>, private authService: AuthService
    ) { }

    public doSearchByReleaseNumber() {

        console.log('Release# lookup. Value entered in form: ' + this.releaseLookupForm.value.releaseNumberInput);
        this.releaseInfoSvc.getRelease({ releaseId: this.releaseLookupForm.value.releaseNumberInput }).then((releaseInfoList) => {
            this.releaseInfoList = releaseInfoList;
        });
    }

}