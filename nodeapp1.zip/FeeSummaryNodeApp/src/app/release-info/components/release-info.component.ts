import { Component } from '@angular/core';
import { ReleaseInfo } from '../models/ReleaseInfo';
import { ReleaseInfoService } from './../services/release-info.service';
import { FormControl, FormGroup } from '@angular/forms';
import { Router, ActivatedRoute, Params } from '@angular/router';

@Component({
    selector: 'release-info',
    template: `
    <h3>Release Info Component</h3>
    <!--<form novalidate [formGroup]="releaseLookupForm">
    <div>
        <label for="release_number-input">Release#</label>
        <input type="text" id="release_number-input"
            formControlName="releaseNumberInput">
        <button type="button" (click)="doSearchByReleaseNumber()">Lookup</button>            
    </div>
    <div>
        <label for="release_description-input">Release Description</label>
        <input type="text" id="release_description-input"
            formControlName="releaseDescriptionInput">
        <button type="button" (click)="doSearchByReleaseDescription()">Lookup</button>            
    </div>  
    </form> --> 
    <div>
        <li *ngFor="let releaseInfo of releaseInfoList">{{releaseInfo.releaseid}}</li>
    </div>
    `,
})
export class ReleaseInfoComponent {

    releaseInfoList: ReleaseInfo[];

    /*public releaseLookupForm = new FormGroup({
        releaseNumberInput: new FormControl(''),
        releaseDescriptionInput: new FormControl(''),
    });*/

    constructor(
        private releaseInfoSvc: ReleaseInfoService<ReleaseInfo>, private activatedRoute: ActivatedRoute
    ) { }



    public ngOnInit() {

        // subscribe to router event
        /*this.activatedRoute.queryParams.subscribe((params: Params) => {
            let loanNumber = params['loannumber'];
            let loggedInUser = params['username'];
            console.log('Loan number from parent app' + loanNumber);
            console.log('User authenticated in parent app' + loggedInUser);
        });*/

        this.releaseInfoSvc.getAll().then((releaseInfoList) => {
            this.releaseInfoList = releaseInfoList;
        });

    }

    /*releaseInfoList: ReleaseInfo[] = [

        { releaseNumber: 'REL-100', jiraNumber: 'CP-100', description: 'test', releaseDate: '05/01/2017', docFolder: 'test/test/doc1.doc' },
        { releaseNumber: 'REL-101', jiraNumber: 'CP-110', description: 'test', releaseDate: '05/01/2017', docFolder: 'test/test/doc2.doc' },
        { releaseNumber: 'REL-102', jiraNumber: 'CP-120', description: 'test', releaseDate: '05/01/2017', docFolder: 'test/test/doc3.doc' },

    ];*/
}
