import { Injectable } from '@angular/core';
import { Http, RequestOptions, Headers } from '@angular/http';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/toPromise';
import { ReleaseInfo } from './../models/ReleaseInfo';
import { Criteria } from './../../shared/models/criteria';

@Injectable()
export class ReleaseInfoService<T extends ReleaseInfo>{

    private requestOptions = new RequestOptions({
        headers: new Headers({
            'Content-Type': 'application/json',
            'Authorization': 'Basic ZmVlX3N1bW1hcnlfdGVtcDpmZWVmdW5zZWM=',
        }),
    });

    constructor(private http: Http) {
    }

    public getAll(): Promise<T[]> {
        return this.http.get('http://localhost:3000/api/releaseinfo')
            .map((res) => res.json()).toPromise();
    }
    public getRelease(criteria: Criteria): Promise<T[]> {

        return this.http.post('http://localhost:3000/api/releaseid/lookup', JSON.stringify(criteria), this.requestOptions)
            .map((res) => res.json()).toPromise();
    }
}
