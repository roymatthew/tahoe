import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { ErrorHandler, ApplicationRef } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { RouterModule } from '@angular/router';
//import { AUTH_PROVIDERS } from 'angular2-jwt';
import 'rxjs/add/observable/throw';

import './rxjs-extensions';
import { AppComponent } from './app.component';
import { routing, routedComponents } from './app.routing';
import { SharedModule } from './shared/shared.module';
import { AuthService } from './shared/services/auth.service';
import { AuthGuard } from './auth-guard.service';
import { GatewayService } from './shared/services/gateway.service';
import { ReleaseInfoService } from './release-info/services/release-info.service';
import { FeeInfoService } from './fee/services/fee-info.service';
import { CookieService } from 'ng2-cookies';
import { GlobalErrorHandler } from './shared/util/error-handler';
import { DpDatePickerModule } from 'ng2-date-picker';
import { Router} from '@angular/router';


@NgModule({
  declarations: [
    AppComponent,
    routedComponents
  ],
  imports: [
    HttpModule,
    BrowserModule,
    routing,
    RouterModule,
    FormsModule,
    ReactiveFormsModule,
    SharedModule,
    DpDatePickerModule,
  ],
  providers: [{ provide: ErrorHandler, useClass: GlobalErrorHandler }, AuthService, AuthGuard, GatewayService,
    ReleaseInfoService, FeeInfoService, CookieService],
  bootstrap: [AppComponent]
})
export class AppModule { }
