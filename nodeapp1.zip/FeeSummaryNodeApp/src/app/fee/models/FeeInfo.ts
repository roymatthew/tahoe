export interface FeeInfo {
    loanNumber: string;
    mtgSkSeq: string;
    primBorrowerLastName: string;
    primBorrowerFirstName: string;
    primBorrowerMiddleInitial: string;
    retailWhlsaleType: string;
    mortgageStatus: string;
    lenderName: string;
    lenderKey: string;
}


