import { Component, OnDestroy } from '@angular/core';
import { FeeInfo } from '../models/FeeInfo';
import { FormControl, FormGroup } from '@angular/forms';
import { FeeInfoService } from './../services/fee-info.service';
import { AuthService } from '../../shared/services/auth.service';
import { Subscription } from 'rxjs/Subscription';
@Component({
    selector: 'fee-info',
    template: `
    <h3>Fee Info Component</h3>
        <div>
        <button type="button" (click)="checkTokenValidity('applied')">Applied Fees</button>
        <button type="button" (click)="checkTokenValidity('available')">Available Fees</button>
        <button type="button" (click)="checkTokenValidity('test')">Negative Test</button>                            
    </div>

    <div>
        {{feeInfo | json}}
    </div>
    `,
})
export class FeeInfoComponent implements OnDestroy {
    feeInfo: any;
    subscription: Subscription;
    endpoint: string;

    /*public releaseLookupForm = new FormGroup({
        releaseNumberInput: new FormControl(''),
        releaseDescriptionInput: new FormControl(''),
    });*/

    constructor(
        private feeInfoSvc: FeeInfoService<FeeInfo>, private authService: AuthService
    ) {
        /*this.subscription = this.feeInfoSvc.getFeeInfo().subscribe(
            message => {
                console.log(message);
                this.feeInfo = message.feeSummaryList;
            }
        );*/

        this.subscription = authService.checkTokenValidity().
            finally(() => {

            }).
            subscribe(
            message => {
                this.endpoint = message as string;
                console.log('FeeInfoComponent constructor :: subscription message is ' + this.endpoint);
                this.serviceCall();
            },
            error => {
                console.log('Refresh token service error' + error);
            }

            );
    }



    public ngOnInit() {

        /*this.feeInfoSvc.getFeeInfo('602810602').then((inFeeInfo) => {
            this.feeInfo = inFeeInfo;
        });*/
        //this.feeInfoSvc.checkTokenValidity('applied');
    }


    ngOnDestroy() {
        // unsubscribe to ensure no memory leaks
        this.subscription.unsubscribe();
    }

    public checkTokenValidity(endPoint: string) {
        console.log('FeeInfoComponent::checkTokenValidity(). arg = ' + endPoint);
        this.feeInfoSvc.tokenRequiresRefresh(endPoint);
    }

    public serviceCall() {
        if (typeof this.endpoint !== 'undefined' && this.endpoint === 'applied') {
            this.getAppliedFees();
        } else if (typeof this.endpoint !== 'undefined' && this.endpoint === 'available') {
            this.getAvailableFees();
        } else {
            console.log('FeeInfoComponent::serviceCall(). Unknown endpoint ' + this.endpoint + ' requested..Exiting function..');
            this.feeInfo = {};
        }
    }
    public getAvailableFees() {

        this.feeInfoSvc.getAvailableFees().then((inFeeInfo) => {
            this.feeInfo = inFeeInfo;
        });

    }

    public getAppliedFees() {

        this.feeInfoSvc.getAppliedFees().then((inFeeInfo) => {
            this.feeInfo = inFeeInfo;
        });

    }
}
