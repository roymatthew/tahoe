import { AuthService } from './../../shared/services/auth.service';
import { Injectable } from '@angular/core';
import { Http, RequestOptions, Headers } from '@angular/http';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/toPromise';
import 'rxjs/add/observable/throw';
import { Observable } from 'rxjs/Observable';
import { FeeInfo } from '../models/FeeInfo';
import { TokenTimeoutException } from '../../shared/util/token-timeout';
import { Subscription } from 'rxjs/Subscription';
import { Subject } from 'rxjs/Subject';

@Injectable()
export class FeeInfoService<T extends FeeInfo>{
    private requestOptions = new RequestOptions({
        headers: new Headers({
            'Content-Type': 'application/json',
        }),
    });

    constructor(private http: Http, private authService: AuthService) { }

    public getAppliedFees(): Promise<T[]> {

        console.log('Enter getAppliedFees');
        const loanNumber = sessionStorage.getItem('loanNumber');
        const headers = new Headers();
        const accessToken = localStorage.getItem('id_token');
        headers.append('token', accessToken);
        const options = new RequestOptions({ headers: headers });
        const endpoint = 'https://wholesale.dev.flagstar.com/esb/fees/loan/' + loanNumber + '/applied';
        console.log('Endpoint: ' + endpoint);
        return this.http.get(endpoint, options)
            .map((res) => res.json()).toPromise();

        //return this.jsonResponse.asObservable();
        /*setTimeout(() => {
            console.log('Waiting for http call to finish...');
        }, 5000);
        return Promise.resolve(JSON.parse(JSON.stringify(responseJson)));*/

    }

    public getAvailableFees(): Promise<T[]> {

        console.log('Enter getAvailableFees');
        const loanNumber = sessionStorage.getItem('loanNumber');
        const headers = new Headers();
        const accessToken = localStorage.getItem('id_token');
        headers.append('token', accessToken);
        const options = new RequestOptions({ headers: headers });
        const endpoint = 'https://wholesale.dev.flagstar.com/esb/fees/loan/' + loanNumber + '/available';
        console.log('Endpoint: ' + endpoint);
        return this.http.get(endpoint, options)
            .map((res) => res.json()).toPromise();

        //return this.jsonResponse.asObservable();
        /*setTimeout(() => {
            console.log('Waiting for http call to finish...');
        }, 5000);
        return Promise.resolve(JSON.parse(JSON.stringify(responseJson)));*/

    }

    public tokenRequiresRefresh(endPoint: string) {
        console.log('1. Enter FeeInfoService.tokenRequiresRefresh(). arg = ' + endPoint);
        this.authService.tokenRequiresRefresh(endPoint);
    }

}
