import { Injectable } from '@angular/core';
import { Http, RequestOptions, Headers } from '@angular/http';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/toPromise';
import { Observable } from 'rxjs/Rx';
import { SecurityToken } from './../models/SecurityToken';
import { Credentials } from './../models/Credentials';
@Injectable()
export class GatewayService {
    private shortToken: SecurityToken;
    private requestOptions = new RequestOptions({
        headers: new Headers({
            'Content-Type': 'application/x-www-form-urlencoded',
            'Authorization': 'Basic ZmVlX3N1bW1hcnlfdGVtcDpmZWVmdW5zZWM='
        }),
    });
    constructor(private http: Http) { }
    public getAcessToken(credentials: Credentials): Promise<SecurityToken> {
        /*this.shortToken = { token: 'xxxxxx', expires: 60 };

        const myFirstPromise = new Promise((resolve, reject) => {
            setTimeout(function () {
                resolve(this.shortToken); // Yay! Everything went well!
            }, 250);
        });
        return myFirstPromise.then((aToken: SecurityToken) => {
            console.log('GatewayService token: ' + aToken);
            return aToken;
        });*/

        console.log('credentials: ' + JSON.stringify(credentials));
        /*return this.http.get('http://localhost:3000/api/shorttoken')
            .map((res) => res.json()).toPromise();*/
        const nodeAuthServerurl = 'http://localhost:4000/auth/accesstoken';
        return this.http.post(nodeAuthServerurl, JSON.stringify(credentials), this.requestOptions)
            .map((res) => res.json()).toPromise();
    }

    public getAcessTokenFromDevServer(): Promise<any> {
        let devAuthServerUrl = 'https://www.dev.flagstar.com/fsb-security/tokenservices/oauth/token?grant_type=password';
        //const body = 'username=rmathew&password=Jun20176*';
        const loggedInUser = sessionStorage.getItem('loggedInUser');
        const loanNumber = sessionStorage.getItem('loanNumber');
        const body = new URLSearchParams();
        body.set('username', 'rmathew');
        body.set('password', 'Jun20176*');
        body.set('authorized_user', loggedInUser);
        // switching to localhost:5000
        devAuthServerUrl = 'http://localhost:5000/token/exchangeshorttoken?';
        devAuthServerUrl = devAuthServerUrl + 'loanNumber=' + loanNumber + '&loginName=' + loggedInUser;
        const theHeaders = new Headers();
        //theHeaders.set('Authorization', 'Basic ZmVlX3N1bW1hcnlfdGVtcDpmZWVmdW5zZWM=');
        theHeaders.set('Content-Type', 'application/x-www-form-urlencoded');
        const localRequestOptions = new RequestOptions({
            headers: theHeaders
        });

        console.log('header keys: ' + theHeaders.keys());
        console.log('Content_type: ' + theHeaders.get('Content-Type'));
        console.log('body: ' + body);
        //console.log('Authorization: ' + theHeaders.get('Authorization'));

        return this.http.post(devAuthServerUrl, body, localRequestOptions)
            .map((res) => res.json())
            //.catch((error: any) => Observable.throw(error.json().error || 'Server error'))
            .catch((error: any) => {throw new Error('');})
            .toPromise();
    }

    public getAcessTokenFromDevESBServer(): Promise<any> {
        const devESBServerUrl = 'https://esb.dev.flagstar.com/fees/accesstoken?grant_type=password&loan_number=602810602';
        //const devESBServerUrl = 'https://wholesale.dev.flagstar.com/esb/fees/accesstoken?grant_type=password&loan_number=602810602';
        const body = 'username=rmathew&password=Jun20176*';
        const theHeaders = new Headers();
        theHeaders.set('Content-Type', 'application/x-www-form-urlencoded');
        //theHeaders.set('Authorization', 'Basic ZmVlX3N1bW1hcnlfdGVtcDpmZWVmdW5zZWM=');
        const localRequestOptions = new RequestOptions({
            headers: theHeaders
        });
        console.log('header keys: ' + theHeaders.keys());

        return this.http.post(devESBServerUrl, body, localRequestOptions)
            .map((res) => res.json())
            .catch((error: any) => Observable.throw(error.json().error || 'Server error'))
            .toPromise();
    }
    // this function is used to exchange the initial short token for access and refresh tokens.
    public exchangeShortTokenFromDEVProxyESBServer(): Promise<any> {
        console.log('Enter gatewayService.exchangeShortTokenFromDEVProxyESBServer()');
        let devProxyESBServerUrl = 'https://wholesale.dev.flagstar.com/esb/fees/exchangeshorttoken?';
        const loanNumber = sessionStorage.getItem('loanNumber');
        const loggedInUser = sessionStorage.getItem('loggedInUser');
        const shortToken = sessionStorage.getItem('shortToken');
        devProxyESBServerUrl = devProxyESBServerUrl + 'loanNumber=' + loanNumber + '&loginName=' + loggedInUser;
        const headers = new Headers({ 'Content-Type': 'application/x-www-form-urlencoded' });
        const requestOptions = new RequestOptions({ headers: headers });
        //const body = new URLSearchParams();
        //body.set('token', shortToken);
        const body = 'token=' + shortToken;
        console.log('header keys: ' + headers.keys());
        console.log('body: ' + body);

        return this.http.post(devProxyESBServerUrl, body, requestOptions)
            .map((res) => res.json())
            .catch((error: any) => Observable.throw(error.json().error || 'Server error'))
            .toPromise();
    }
    // this function is used to exchange the refresh token for new access and refresh tokens.
    public exchangeRefreshTokenFromDEVProxyESBServer(): Promise<any> {
        console.log('Enter gatewayService.exchangeRefreshTokenFromDEVProxyESBServer()');
        const devProxyESBServerUrl = 'https://wholesale.dev.flagstar.com/esb/fees/exchangerefreshtoken?grant_type=refresh_token';
        const refreshToken = localStorage.getItem('refresh_token');
        const headers = new Headers({ 'Content-Type': 'application/x-www-form-urlencoded' });
        const options = new RequestOptions({ headers: headers });
        const body = 'token=' + refreshToken;
        return this.http.post(devProxyESBServerUrl, body, options)
            .map((res) => res.json())
            .catch((error: any) => Observable.throw(error.json().error || 'Server error'))
            .toPromise();
    }

    /* This is a call to Mule API on local runtime to get a token with user profile embedded within */
    public getAcessTokenFromLocalMuleAPI(loanNumber: string, loginName: string, inToken: string): Promise<any> {
        console.log('Enter gatewayService.getAcessTokenFromLocalMule()');
        const body = new URLSearchParams();
        body.set('token', inToken);
        const theHeaders = new Headers();
        theHeaders.set('Authorization', 'Basic cm1yc286Um95bWs0U2VjKg==');
        theHeaders.set('Content-Type', 'application/x-www-form-urlencoded');
        const localRequestOptions = new RequestOptions({
            headers: theHeaders
        });
        console.log('header keys: ' + theHeaders.keys());
        console.log('Content_type: ' + theHeaders.get('Content-Type'));
        console.log('Authorization: ' + theHeaders.get('Authorization'));
        const localMuleUrl = 'http://localhost:7080/fees/exchangeshorttoken?grant_type=password&'
            + 'loanNumber=' + loanNumber + '&loginName=' + loginName;

        console.log('localMuleUrl: ' + localMuleUrl);

        return this.http.post(localMuleUrl, body, localRequestOptions)
            .map((res) => res.json())
            .catch((error: any) => Observable.throw(error.json().error || 'Server error'))
            .toPromise();

    }

    public lookupReleaseById(): Promise<any> {
        return null;
    }
}