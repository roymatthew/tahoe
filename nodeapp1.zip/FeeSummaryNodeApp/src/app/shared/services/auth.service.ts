import { Injectable } from '@angular/core';
//import { Http, Headers, RequestOptions, URLSearchParams } from '@angular/http';
import { tokenNotExpired, JwtHelper } from 'angular2-jwt';
import { Cookie } from 'ng2-cookies';
import { CookieService } from 'ng2-cookies';
import { Router } from '@angular/router';
import { GatewayService } from './gateway.service';
import { SecurityToken } from '../models/SecurityToken';
import { Observable } from 'rxjs/Observable';
import { Subject } from 'rxjs/Subject';

import { TokenTimeoutException } from '../../shared/util/token-timeout';


@Injectable()
export class AuthService {

    private ssoTokenCookie: any;
    private ssoToken: any;
    private idToken: any;
    private accessToken: string;
    // private refreshToken: string;
    private jti: string;
    private expiresIn: string;
    private jwtHelper: JwtHelper = new JwtHelper();
    requireLoginSubject: Subject<boolean>;
    tokenIsBeingRefreshed: Subject<boolean>;
    endpointToBeInvoked: Subject<string>;

    constructor(private router: Router,
        private gatewayService: GatewayService, private cookieService: CookieService) {

        this.requireLoginSubject = new Subject<boolean>();
        this.tokenIsBeingRefreshed = new Subject<boolean>();
        this.endpointToBeInvoked = new Subject<any>();
        this.tokenIsBeingRefreshed.next(false);
    }

    login() {
        console.log('Enter login()');
        //this.getSsoTokenCookie();
        // const res = this.ssoTokenCookie.split('.');



        const shortToken = sessionStorage.getItem('shortToken');

        console.log('shortToken: ' + shortToken);


        /*this.gatewayService.getAcessTokenFromLocalMuleAPI(loanNumber, loggedInUser, shortToken).then((sToken: any) => {

            const text = JSON.stringify(sToken);
            sToken = JSON.parse(text);
            console.log('Access token received from mule:' + sToken.access_token);
            localStorage.setItem('id_token', sToken.access_token);
            localStorage.setItem('refresh_token', sToken.refresh_token);
            sessionStorage.removeItem('shortToken');

        });*/
        /*this.gatewayService.getAcessTokenFromDevServer().then((sToken: any) => {
            console.log('Enter gatewayService.getAcessTokenFromDevServer()');
            const text = JSON.stringify(sToken);
            sToken = JSON.parse(text);
            //localStorage.setItem('id_token', sToken.access_token);
            this.addTokens(sToken.access_token, sToken.refresh_token);
        });*/

        this.gatewayService.exchangeShortTokenFromDEVProxyESBServer().then((sToken: any) => {
            console.log('Call back received from gateway service');
            const text = JSON.stringify(sToken);
            sToken = JSON.parse(text);
            this.addTokens(sToken.access_token, sToken.refresh_token);
        });


        //this.router.navigateByUrl('/dashboard');

        /*this.gatewayService.getAcessToken({
            loginname: res[0],
            password: btoa('rp4ang2'),
            clientId: res[1],
            secret: res[2],
        }).then((sToken: SecurityToken) => {

            const text = JSON.stringify(sToken);
            //console.log('From AuthService - text: ' + text);
            sToken = JSON.parse(text);

            try {
                const parts = sToken.token.split('.');
                console.log('From AuthService - part1: ' + atob(parts[0]));
                console.log('From AuthService - part2: ' + atob(parts[1]));
                console.log('From AuthService - part3: ' + atob(parts[2]));
                localStorage.setItem('id_token', sToken.token);
            } catch (Error) {
                console.log('Error in AuthService when doing atob on JWT token parts: ' + Error.message);
            }

        });*/

        /*this.gatewayService.getAcessTokenFromDevServer().then((sToken: any) => {
            console.log('Enter gatewayService.getAcessTokenFromDevServer()');
            const text = JSON.stringify(sToken);
            sToken = JSON.parse(text);
            localStorage.setItem('id_token', sToken.access_token);

        });*/



    }

    /*getSsoTokenCookie() {
        let text = '';

        console.log('Enter getSsoTokenCookie');

        if (Cookie.check('ssoAccess_local')) {
            this.accessToken = Cookie.get('ssoAccess_local');
            var parts = this.accessToken.split('.');
            if (parts.length !== 3) {
                console.log('access token does not have 3 parts');
            }
            else {
                console.log('access token has 3 parts');
            }
            //console.log('accessToken: ' + this.accessToken);
        }

        if (Cookie.check('ssoRefresh_local')) {
            this.refreshToken = Cookie.get('ssoRefresh_local');
            //console.log('refreshToken: ' + this.refreshToken);

        }

        if (Cookie.check('ssoExpire_local')) {
            this.expiresIn = Cookie.get('ssoExpire_local');
            console.log('expiresIn: ' + this.expiresIn);

        }

        if (Cookie.check('ssoJti_local')) {
            this.jti = Cookie.get('ssoJti_local');
            console.log('jti: ' + this.jti);

        }

        if (typeof this.accessToken != 'undefined') {
            localStorage.setItem('id_token', this.accessToken);
        }
        else {
            console.log('accessToken is undefined!');
        }


}*/

    loggedIn() {
        //console.log('Enter loggedIn');
        //const tokenFromStore = localStorage.getItem('id_token');
        //console.log('tokenFromStore: ' + tokenFromStore);
        return tokenNotExpired('id_token');

    }

    /*logout() {
        console.log('Enter logout()');
        localStorage.removeItem('id_token');
        const tokenFromStore = localStorage.getItem('id_token');
        if (tokenFromStore === null) {
            console.log('localstorage token removed.');
        }
        this.router.navigateByUrl('/dashboard');
    }*/


    addTokens(accessToken: string, refreshToken: string) {
        localStorage.setItem('id_token', accessToken);
        localStorage.setItem('refresh_token', refreshToken);
    }

    getRefreshTokenExpirationDate() {
        const token = localStorage.getItem('id_token');
        if (token) {
            const tokenExpDate = this.jwtHelper.getTokenExpirationDate(token);
            const sessionExpDate = new Date(tokenExpDate.getTime() + 4 * 60000);
            if (new Date() > sessionExpDate) {
                this.logout();
            }
            return sessionExpDate;
        }

        return null;
    }

    hasRefreshToken() {
        const refToken = localStorage.getItem('refresh_token');

        if (refToken == null) {
            this.logout();
        }

        return refToken != null;
    }

    refreshTokenSuccessHandler(data) {
        if (data.error) {
            console.log('Removing tokens.');
            this.logout();
            this.requireLoginSubject.next(true);
            this.tokenIsBeingRefreshed.next(false);
            this.router.navigateByUrl('/unauthorized');
            return false;
        } else {
            this.addTokens(data.access_token, data.refresh_token);
            this.requireLoginSubject.next(false);
            this.tokenIsBeingRefreshed.next(false);
            console.log('Refreshed user token');
        }
    }

    refreshTokenErrorHandler(error) {
        this.requireLoginSubject.next(true);
        this.logout();
        this.tokenIsBeingRefreshed.next(false);
        this.router.navigate(['/sessiontimeout']);
        console.log(error);
    }

    /*refreshToken(callback: (token: any) => void) {
        console.log('Enter AuthService.refreshToken.');
        // const refToken = localStorage.getItem('refresh_token');
        // let refTokenId = this.jwtHelper.decodeToken(refToken).refreshTokenId;
        this.gatewayService.exchangeRefreshTokenFromDEVProxyESBServer().then((sToken: any) => {
            console.log('Within AuthService.refreshToken::Call back received from gateway service');
            const text = JSON.stringify(sToken);
            sToken = JSON.parse(text);
            this.addTokens(sToken.access_token, sToken.refresh_token);
            callback(sToken);
        });
    }*/

    /*tokenRequiresRefresh(): boolean {
        if (!this.loggedIn()) {
            console.log('Token refresh is required');
        } else {
            console.log('Token refresh is NOT required');
        }
        return !this.loggedIn();

        this.refreshToken(function (data) {
            console.log('Obtained refresh token::Here you go..');
        });

        return true;
    }*/


    tokenRequiresRefresh(endPoint) {
        console.log('2. Enter AuthService.tokenRequiresRefresh');
        if (!this.loggedIn()) {
            console.log('3. Token refresh is required');
            console.log('Calling refreshToken');
            this.refreshToken(endPoint);
            console.log('Tokens have been refreshed');
        } else {
            console.log('4. Token refresh is NOT required');
            this.endpointToBeInvoked.next(endPoint);
        }

    }

    refreshToken(endPoint) {
        console.log('5. Enter AuthService.refreshToken.');
        this.gatewayService.exchangeRefreshTokenFromDEVProxyESBServer().then((sToken: any) => {
            console.log('Within AuthService.refreshToken::Call back received from gateway service');
            const text = JSON.stringify(sToken);
            sToken = JSON.parse(text);
            this.addTokens(sToken.access_token, sToken.refresh_token);
            this.endpointToBeInvoked.next(endPoint);
        });
    }

    checkTokenValidity(): Observable<any> {
        console.log('6. Enter AuthService.checkTokenValidity()');
        return this.endpointToBeInvoked.asObservable();
    }

    logout() {
        localStorage.removeItem('id_token');
        localStorage.removeItem('refresh_token');
        this.requireLoginSubject.next(true);
    }

}
