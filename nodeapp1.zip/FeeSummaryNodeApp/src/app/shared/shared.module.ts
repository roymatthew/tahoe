import { NgModule } from '@angular/core';
import { GatewayService } from './services/gateway.service';

@NgModule({
    imports: [],
    declarations: [],
    providers: [GatewayService],
})
export class SharedModule { }
