export class Credentials {
    loginname: string;
    password: string;
    clientId: string;
    secret: string;
}