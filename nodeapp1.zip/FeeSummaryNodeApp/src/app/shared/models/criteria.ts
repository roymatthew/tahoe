export class Criteria {
    releaseId: string;
}
