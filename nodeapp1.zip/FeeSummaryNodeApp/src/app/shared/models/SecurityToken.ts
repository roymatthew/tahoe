import { User } from './User';
export class SecurityToken {
    token: any;
    expires: number;
    user: User;
}