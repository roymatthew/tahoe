export class User {
    loginname: string;
    password: string;
    authorities: string[];
}