import { ErrorHandler, Injectable } from '@angular/core';
import { TokenTimeoutException } from './token-timeout';
import 'rxjs/add/observable/throw';

@Injectable()
export class GlobalErrorHandler extends ErrorHandler {
    constructor() { super(false); }

    public handleError(error: any): void {
        console.log('Hio');
        console.log(error.message);
        if (error instanceof Error && typeof error.message !== 'undefined' && error.message.indexOf('Refresh token has expired') > 0) {
            console.log('Error message check passed');
        } else {
            super.handleError(error);
        }
    }

}