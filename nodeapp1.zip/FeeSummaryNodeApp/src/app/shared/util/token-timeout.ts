export class TokenTimeoutException {

    message: string;

   /* originalError: Error;*/

    constructor(msg?: string) {
        //super(msg);
        this.message = msg;
    }

    toString() {
        return this.message;
    }
}