import { FeeSummaryNodeAppPage } from './app.po';

describe('fee-summary-node-app App', () => {
  let page: FeeSummaryNodeAppPage;

  beforeEach(() => {
    page = new FeeSummaryNodeAppPage();
  });

  it('should display message saying app works', () => {
    page.navigateTo();
    expect(page.getParagraphText()).toEqual('app works!');
  });
});
